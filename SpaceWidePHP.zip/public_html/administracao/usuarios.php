<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/src/inicializador.php');
require($_SERVER['DOCUMENT_ROOT'] . '/src/libs/acesso/acesso_admin.libs.php');


if (isset($_GET['pagina']) && $_GET['pagina'] != ""):
	$pagina = $_GET['pagina'];
else:
	$pagina = 1;
endif;

$limite = 7;
$pagina_inicial = ($pagina -1) * $limite;
$pagina_anterior = $pagina - 1;
$pagina_sucessora = $pagina + 1;

$mysqli = conectar_bd();

if (!isset($_GET['sort']) && !isset($_GET['search-bar'])):

    $sql_total = "SELECT 
                    (SELECT COUNT(id) FROM administrador) +
                    (SELECT COUNT(id) FROM artista) +  
                    (SELECT COUNT(id) FROM cliente) AS quantidade_de_usuarios";

    $sql = sprintf("SELECT id, nome, email, 'administrador' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM administrador WHERE id != %d
                    UNION 
                    SELECT id, nome, email, 'artista' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM artista 
                    UNION  
                    SELECT id, nome, email, 'cliente' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM cliente
                    ORDER BY id DESC
                    LIMIT %d, %d", $_SESSION['id'], $pagina_inicial, $limite);


elseif (isset($_GET['sort-btn'])):

    $opcao_do_filtro = filter_input(INPUT_GET, 'sort');

    if ($opcao_do_filtro == "0"):
        $filtro = "ORDER BY id DESC";
    elseif ($opcao_do_filtro == "1"):
        $filtro = "ORDER BY nome ASC";
    elseif($opcao_do_filtro == "2"):
        $filtro = "ORDER BY nome DESC";
    elseif($opcao_do_filtro == "3"):
        $filtro = "ORDER BY data_de_criacao DESC";
    elseif($opcao_do_filtro == "4"):
         $filtro = "ORDER BY data_de_criacao ASC";
    endif;

    $sql_total = "SELECT 
                    (SELECT COUNT(id) FROM administrador) +
                    (SELECT COUNT(id) FROM artista) +  
                    (SELECT COUNT(id) FROM cliente) AS quantidade_de_usuarios";

    $sql = sprintf("SELECT id, nome, email, 'administrador' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM administrador WHERE id != %d
                    UNION 
                    SELECT id, nome, email, 'artista' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM artista 
                    UNION 
                    SELECT id, nome, email, 'cliente' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM cliente 
                    %s LIMIT %d, %d", $_SESSION['id'], $filtro, $pagina_inicial, $limite);
    
else:

    $item_de_pesquisa = filter_input(INPUT_GET, 'search-bar');
    
    $sql_total = "SELECT 
                    (SELECT COUNT(id) FROM administrador WHERE LOWER(CONCAT(nome,email,estado)) LIKE LOWER('%". $item_de_pesquisa ."%')) +
                    (SELECT COUNT(id) FROM artista WHERE LOWER(CONCAT(nome,email,estado)) LIKE LOWER('%". $item_de_pesquisa ."%')) +  
                    (SELECT COUNT(id) FROM cliente WHERE LOWER(CONCAT(nome,email,estado)) LIKE LOWER('%". $item_de_pesquisa ."%')) AS quantidade_de_usuarios";

    $sql = "SELECT id, nome, email, 'administrador' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM administrador 
            WHERE LOWER(CONCAT(nome, 'administrador', email, estado)) LIKE LOWER('%" .$item_de_pesquisa . "%') AND id != ". $_SESSION['id'] .
            " UNION
            SELECT id, nome, email, 'artista' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM artista 
            WHERE LOWER(CONCAT(nome, 'artista', email, estado)) LIKE LOWER('%" .$item_de_pesquisa . "%') 
            UNION 
            SELECT id, nome, email, 'cliente' AS acesso, estado, codigo_validador, data_de_criacao, data_da_ultima_modificacao FROM cliente 
            WHERE LOWER(CONCAT(nome, 'cliente', email, estado)) LIKE LOWER('%". $item_de_pesquisa . "%') 
            ORDER BY id DESC LIMIT ". $pagina_inicial. ", ". $limite;

endif;


$stmt = $mysqli->prepare($sql);
$stmt->execute();
$resultado = $stmt->get_result();

$stmt_total = $mysqli->prepare($sql_total);
$stmt_total->execute();
$resultado_total = $stmt_total->get_result();

$numero_de_resultados = $resultado_total->fetch_assoc();
$numero_de_paginas = ceil((int)$numero_de_resultados['quantidade_de_usuarios'] / $limite);
$penultima_pagina = $numero_de_paginas - 1;

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" type="text/css" href="/src/inc/css/table.css">
    <link rel="shortcut icon" href="/src/inc/assets/log">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>

    
    <title>Administracao de usuarios</title>
</head>
<body>
<header id="body">
    <?php 
    require_once($_SERVER["DOCUMENT_ROOT"] . "/src/inc/menu.php"); 
    //require($_SERVER['DOCUMENT_ROOT'] . '/src/gerar_grafico.php');
    
    ?>
</header>
        <div class="conteiner">
            <form action="" method="GET">
                <div class="sort_box">
                    <select name="sort" class="sort-control">
                        <option name="sort-option" value="0">selecione alguma opção</option>
                        <option name="sort-option" value="1" <?php if (isset($_GET['sort']) && $_GET['sort'] == 1) { echo 'selecionado';} ?> >ordem alfabética</option>
                        <option name="sort-option" value="2" <?php if (isset($_GET['sort']) && $_GET['sort'] == 2) { echo 'selecionado';} ?> >ordem alfabética reversa</option>
                        <option name="sort-option" value="3" <?php if (isset($_GET['sort']) && $_GET['sort'] == 3) { echo 'selecionado';} ?> >mais recente</option>
                        <option name="sort-option" value="4" <?php if (isset($_GET['sort']) && $_GET['sort'] == 4) { echo 'selecionado';} ?> >mais antigo</option>
                    </select>
                    <button type="sort-submit" name="sort-btn" class="btn">Filtrar</button>
                </div>
                
                <div class="search-box">
                    <input type="text" name="search-bar" class="btn" value="<?php if(isset($_GET['search-bar'])) {echo $_GET['search-bar']; } ?>" >
                    <button type="search-submit" name="search-btn" class="btn">Buscar</button>
                </div>
            </form>
            
            <form action="/src/editar_usuarios.php" class="form" method="POST">
                <table class="table">
                    <tbody>
                        <tr>
                            <th>
                                <button type='submit' name='create-btn' class='btn'>Criar novo administrador</button>
                            </th>
                            <th>
                                <button type='submit' name='update-btn' class='btn'>Atualizar</button>
                            </th>
                            <th>
                                <button type='submit' name='delete-btn' class='btn'>Deletar</button>
                            </th>
                        </tr>
                        <tr>
                            <th></th>
                            <th>nome</th>
                            <th>email</th>
                            <th>estado</th>
                            <th>acesso</th>
                            <th>codigo_validador</th>
                            <th>data_de_criacao</th>
                            <th>data da ultima modificacao</th>
                        </tr>
                    </tbody>

                    <tbody>
                        <?php
                        
                        if ($resultado->num_rows > 0) {
                            while ($row = $resultado->fetch_assoc()) {

                        ?>

                        <tr>
                            <td><input type='checkbox' name='all-checkboxes[]' value='<?= $row["id"] ."-". $row["acesso"]; ?>'></td>
                            <td> <?= $row['nome']; ?> </td>
                            <td> <?= $row['email']; ?> </td>
                            <td> <?= $row['estado']; ?> </td>
                            <td> <?= $row['acesso']; ?> </td>
                            <td> <?= $row['codigo_validador']; ?> </td>
                            <td> <?= $row['data_de_criacao']; ?> </td>
                            <td> <?= $row['data_da_ultima_modificacao']; ?> </td>
                        </tr>
                        
                        <?php
                            
                        }} else {
                            echo '<tr><td colspan="8">Nenhum usuario encontrado :(</td></tr>';
                            $stmt->close();
                        }
                        
                        ?>
                        
                    </tbody>
                </div>  
            </table>
                   
            </form>
        </div>

        <ul class="paginacao">
        <?php

        $url = parse_url($_SERVER['REQUEST_URI']);
        $url_params = substr($url['query'], 0, strpos($url['query'], '&pagina='));

        ?>
        <?php if ($pagina > 1): ?>
        <li><a href='<?php echo sprintf('?%s&pagina=1', $url_params); ?>'>primeira</a></li>
        <?php endif ?>

        <?php if ($pagina > 2): ?>
        <li><a href='<?php echo sprintf('?%s&pagina=%d', $url_params, $pagina_anterior); ?>'>anterior</a></li>
        <?php endif ?>

        <?php if ($pagina < $numero_de_paginas): ?>
        <li><a href='<?php echo sprintf('?%s&pagina=%d', $url_params, $pagina_sucessora); ?>'>proxima</a></li>
        <?php endif ?>

        <?php if($pagina < $numero_de_paginas): ?>
        <li><a href='<?php echo sprintf('?%s&pagina=%d', $url_params, $numero_de_paginas); ?>'>ultima</a></li>
        <?php endif ?>

        </ul>

    </div>
</body>
</html>
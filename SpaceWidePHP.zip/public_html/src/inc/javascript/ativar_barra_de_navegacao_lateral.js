const sideNav = document.getElementById("side-nav");

function openNav() {
    sideNav.style.width = "250px";
}

function closeNav() {  
    sideNav.style.width = "0";
}
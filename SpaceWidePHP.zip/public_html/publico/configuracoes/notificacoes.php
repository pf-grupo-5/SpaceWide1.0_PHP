<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/src/inicializador.php');


?>